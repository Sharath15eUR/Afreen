File 5 is a markdown file.
ERROR happens here!
