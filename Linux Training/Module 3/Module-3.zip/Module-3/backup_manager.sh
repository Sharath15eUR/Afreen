#!/bin/bash
sdir="$1"    # Source directory
bdir="$2"    # Backup directory
filex="$3"   # File extension

echo "Script name: $0"
echo "Source directory: $sdir"
echo "Backup directory: $bdir"
echo "File extension: $filex"

# Step 1: Collect files with the specified extension in the source directory
file_array=()
for file in "$sdir"/*"$filex"; do
    if [ -f "$file" ]; then
        file_array+=("$file")
    fi
done

# Step 2: Print the list of files and their sizes
echo "List of files and their respective sizes: "
for file in "${file_array[@]}"; do
    echo "$(basename "$file") - $(du -h "$file" | cut -f1)"
done

# Initialize counters for the report
export BACKUP_COUNT=0
export TOTAL_SIZE=0

# Step 3: Check if the backup directory exists
if [ -d "$bdir" ]; then
    echo "Backup directory exists."
else
    # Create backup directory if it doesn't exist
    if mkdir -p "$bdir"; then
        echo "Successfully created the Backup directory"
    else
        echo "Failed to create the Backup directory"
        exit 1
    fi
fi

# Step 4: Check if the file_array is empty (no files to back up)
if [ ${#file_array[@]} -eq 0 ]; then
    echo "Error: No files with extension '$filex' found in source directory '$sdir'"
    exit 1
fi

# Step 5: Backup files to the backup directory
for file in "${file_array[@]}"; do
    src_file="$file"
    dest_file="$bdir/$(basename "$file")"
    
    # Step 6: If file exists in backup, compare timestamps and only overwrite if source is newer
    if [ -f "$dest_file" ]; then
        # Compare timestamps: If source file is newer than backup file, overwrite
        if [ "$src_file" -nt "$dest_file" ]; then
            echo "Overwriting older backup: $(basename "$file")"
            cp "$src_file" "$dest_file"
            ((BACKUP_COUNT++))
            # Add the size of the file to the total size
            FILE_SIZE=$(du -b "$src_file" | cut -f1)
            ((TOTAL_SIZE+=FILE_SIZE))
        else
            echo "Skipping (up-to-date): $(basename "$file")"
        fi
    else
        # If file doesn't exist in backup directory, copy it
        echo "Copying new file: $(basename "$file")"
        cp "$src_file" "$dest_file"
        ((BACKUP_COUNT++))
        # Add the size of the file to the total size
        FILE_SIZE=$(du -b "$src_file" | cut -f1)
        ((TOTAL_SIZE+=FILE_SIZE))
    fi
done

# Step 7: Generate the report and save it as backup_report.log
report_file="$bdir/backup_report.log"
echo "Backup Report" > "$report_file"
echo "====================" >> "$report_file"
echo "Total files processed: $BACKUP_COUNT" >> "$report_file"
echo "Total size of files backed up: $TOTAL_SIZE bytes" >> "$report_file"
echo "Backup directory: $bdir" >> "$report_file"

# Print a confirmation message
echo "Backup completed. Report saved to $report_file"

